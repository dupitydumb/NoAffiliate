// When the popup is opened, get the stored value and set the checkbox state
chrome.storage.sync.get("enabled", function (data) {
  document.getElementById("toggle").checked = data.enabled;
});

chrome.storage.sync.get("mute", function (data) {
  document.getElementById("toggle2").checked = data.mute;
});
// When the checkbox state is changed, store the new value
document.getElementById("toggle").addEventListener("change", function (e) {
  chrome.runtime.sendMessage({ cmd: "setActive", value: e.target.checked });
});

document.getElementById("toggle2").addEventListener("change", function (e) {
  chrome.runtime.sendMessage({ cmd: "setMute", value: e.target.checked });
});

// ...existing JavaScript...

document.getElementById("restart").addEventListener("click", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.reload(tabs[0].id);
  });
});
