chrome.storage.sync.get("enabled", function (data) {
  if (data.enabled && window.location.hostname.startsWith("twitter.com")) {
    console.log("Running on Twitter");
    function removeElements() {
      var elements = document.getElementsByClassName(
        "css-1qaijid r-bcqeeo r-qvutc0 r-poiln3"
      );

      for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        if (element.textContent.includes("shope.ee")) {
          console.log("Found");
          element.parentElement.parentElement.parentElement.parentElement.parentElement.remove();
          // Since we've modified the DOM, the elements list is now stale. Break the loop.
          break;
        }
      }
    }

    // Run the function initially
    removeElements();

    // Create a MutationObserver instance
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (mutation.addedNodes.length) {
          removeElements();
        }
      });
    });

    // Start observing the document with the configured parameters
    observer.observe(document, { childList: true, subtree: true });
  } else {
    console.log("Not on Twitter or extension is disabled");
  }
});

chrome.storage.sync.get("mute", function (dataETI) {
  console.log(dataETI);
  if (dataETI.mute && window.location.hostname.startsWith("twitter.com")) {
    function removeExtraTimeIndonesia() {
      console.log("Running on Twitter ETI");
      var elements = document.getElementsByClassName(
        "css-175oi2r r-1wbh5a2 r-dnmrzs r-1ny4l3l r-1loqt21"
      );

      for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        if (element.getAttribute("href") === "/idextratime") {
          element.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.remove();
          console.log("Removed Extra Time Indonesia");
          // Since we've modified the DOM, the elements list is now stale. Break the loop.
          break;
        }
      }
    }

    removeExtraTimeIndonesia();

    // Run the function initially
    removeExtraTimeIndonesia();

    // Create a MutationObserver instance
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (mutation.addedNodes.length) {
          removeExtraTimeIndonesia();
        }
      });
    });

    // Start observing the document with the configured parameters
    observer.observe(document, { childList: true, subtree: true });
  } else {
    console.log("Not Found Eti");
  }
});
