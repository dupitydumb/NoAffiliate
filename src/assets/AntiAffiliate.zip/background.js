chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.cmd === "setActive") {
    chrome.storage.sync.set({ enabled: request.value });
    console.log("setActive", request.value);
  }
  if (request.cmd === "setMute") {
    chrome.storage.sync.set({ mute: request.value });
    console.log("setMute", request.value);
  }
});
